﻿# Backend API (Vue Felines Demo)

Node + Express API that serves feline items for the Vue frontend. Data lives in `data/items.js` with title/desc/img/link fields and uses online image URLs.

## Prerequisites
- Node.js 18+

## Installation
```bash
cd backend
npm install
```

## Run
```bash
# production
npm start

# dev with auto-reload
npm run dev
```
Server listens on http://localhost:3000 by default.

## Endpoints
- `GET /item` : current item with `{ index, item, total }`
- `GET /item/next` : next item (wraps)
- `GET /item/prev` : previous item (wraps)
- `GET /item/:id` : item by index (optional spec)

## Quick tests
```bash
curl http://localhost:3000/item
curl http://localhost:3000/item/next
curl http://localhost:3000/item/prev
curl http://localhost:3000/item/2
```

## Submission checklist
- Include: `data/`, `server.js`, `package.json`, `.gitignore`, `README.md`
- Push to GitHub and share the repo link on Moodle along with student names
