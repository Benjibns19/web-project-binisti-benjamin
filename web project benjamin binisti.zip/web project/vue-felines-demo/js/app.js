const app = Vue.createApp({
    data() {
        return {
            mainHeading: 'Felines fact Application',
            isFlipped: false,
            // Ces variables seront remplies par le serveur
            currentItem: null,
            currentIndex: 0,
            totalItems: 0,
            loading: true
        };
    },
    methods: {
        // Fonction principale qui contacte le serveur backend
        async fetchItem(endpoint) {
            this.loading = true;
            try {
                // On appelle l'URL du serveur (port 3000)
                const response = await fetch(`http://localhost:3000${endpoint}`);
                
                if (!response.ok) {
                    throw new Error('Erreur réseau ou serveur');
                }
                
                // On récupère la réponse JSON { index, item, total }
                const data = await response.json();
                
                // On met à jour nos variables Vue
                this.currentItem = data.item;
                this.currentIndex = data.index;
                this.totalItems = data.total;
                
            } catch (error) {
                console.error("Erreur de communication avec le backend:", error);
                alert("Impossible de charger les données. Assure-toi que le serveur backend tourne sur le port 3000 !");
            } finally {
                this.loading = false;
                // On s'assure que la carte est visible côté image quand on change
                this.isFlipped = false;
            }
        },
        next() {
            // Demande l'item suivant au serveur
            this.fetchItem('/item/next');
        },
        prev() {
            // Demande l'item précédent au serveur
            this.fetchItem('/item/prev');
        },
        onImgError(event) {
            // Image de secours si le chemin est incorrect
            event.target.src = "https://via.placeholder.com/800x600?text=Image+Introuvable";
        }
    },
    mounted() {
        // Au chargement de la page, on récupère le premier item
        this.fetchItem('/item');
    }
});

app.mount('#app');